shiboken_library_soversion = str(6.3)

version = "6.3.1"
version_info = (6, 3, 1, "", "")

__build_date__ = '2022-07-31T10:28:42+00:00'
__build_commit_date__ = '2022-06-14T06:37:24+00:00'
__build_commit_hash__ = '7a1ab102e492463e133b80554f86bc1b09e8feb7'
__build_commit_hash_described__ = 'v5.11.2-3007-g7a1ab102e'

__setup_py_package_version__ = '6.3.1'
